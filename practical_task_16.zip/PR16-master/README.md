Практическая работа 16 с использованием JetpackCompose


![image](https://github.com/user-attachments/assets/e42719ab-afe6-435d-bedc-051b6a3e0133)
